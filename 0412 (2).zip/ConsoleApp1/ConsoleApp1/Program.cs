﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("1065번:한수");
            //각 자리가 등차수열을 이루는 수를 한수라고 함
            //n이 주어졌을때 n보다 작거나 같은 한수의 개수
            int n = int.Parse(Console.ReadLine());
            //스트링을 써야하나..?
            if (n < 100)
            {
                Console.WriteLine(n);
            }
            else
            {   //여기서 부터 이해안됨..
                int result = 99;
            }

            



            //java 버전
    //        public class Main
    //    {

    //        public static void main(String[] args) throws IOException
    //        {
    //            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    //    int n = Integer.parseInt(br.readLine());
    //        System.out.println(hansu(n));
    //    }

    //    public static int hansu(int n)
    //    {
    //        int count = 0;
    //        for (int i = 1; i <= n; i++)
    //        {
    //            if (i < 100)
    //                count++;
    //            else if (i < 1000)
    //            {
    //                int a = i / 100; //백의 자리 숫자
    //                int b = (i / 10) % 10; //십의 자리 숫자
    //                int c = (i % 10); //일의 자리 숫자
    //                if ((a - b) == (b - c))
    //                    count++;
    //            }
    //            //1000은 어차피 한수 아니니까 세지 않음
    //        }
    //        return count;
    //    }
    //}





}
    }
}
