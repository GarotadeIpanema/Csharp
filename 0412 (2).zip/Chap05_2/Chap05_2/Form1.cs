﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chap05_2
{
    partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            button1.Text = "안녕하세여";

            //partial: 한 클래스를 두개의 파일로 표현한것; 디자이너파일과 form1파일로 
            //버튼사이즈는 넉넉하게 해서 false로 두는 것이 좋음
            int abc = 100;
            if (abc == 100)
                button1.Enabled = false;
            Button b = new Button();
            b.Text = "무야호";
            b.Location = new Point(50, 50);
            Controls.Add(b);
            //mdi middle container: 폼 안에 새로운 다른 폼이 생성되는 것

            List<int> iList = new List<int>();
            iList.Add(10);
            iList.Add(50);
            iList.Add(123);
            //List:동적으로 움직이는 배열, for문에서 Length대신 count 사용
            for (int i = 0; i < iList.Count; i++)
            {
                Console.WriteLine(iList[i]);
            }
            iList.Add(1000);
            MessageBox.Show(iList.Count + "개");
            //몇개 넣을지 모를때 리스트를 쓰면 좋다
            List<string> sList = new List<string>();
            sList.Add("김가현");
            sList.Add("박지민");
            sList.Add("서정빈");
            sList.Add("양화영");

            MessageBox.Show(sList.Count + "명");
            //sList.Remove("서정빈");
            sList.RemoveAt(2);
            //mbox 탭탭
           
            string names = string.Empty;
            for (int i = 0; i <sList.Count; i++)
            {
                names += sList[i];
            }

            MessageBox.Show(names);
            //math클래스
            Label l = new Label();
            l.Text = "절댓값:" + Math.Abs(-1000);
            l.Location = new Point(100, 100);
            Controls.Add(l);
            //클래스 변수 선언: 클래스 이름과 new 키워드 +인스턴스 P
            //내가 클래스를 사용하여 만든 변수를 인스턴스라고 함

            Product p = new Product();
            p.Name = "감자";
            p.Price = 1000;
            Product.Count++;
            MessageBox.Show("제품명:"+ p.Name);
            MessageBox.Show("제품가격:" + p.Price);
            MessageBox.Show("제품갯수:" + Product.Count);
            
            Product p2 = new Product();
            p.Name = "호박고구마";
            p.Price = 3000;
            Product.Count++;
            //클래스변수(static: 정적, 메모리에 먼저 올라감)와 인스턴스 변수(new키워드와 함께
            //선언될때 메모리 올라감)는 메모리에 올라가는 속도가 다름
            //count는 static 안붙인 인스턴스 변수: 모든 Product가 접근가능한 공통된 변수
            //Product는 클래스 변수
            //1.인스턴스 변수는 클래스이름 점 찍고 밖에 접근이 안됨
            //2.선언과 동시에 값을 지정
            //3. 생성자 사용
            //public Dog(string name, int age)
            //{
            //    this.name = name;
            //    this.age = age;
            //    theNumberofDog++;

            //}


            Product p3 = new Product() { Name="대파", Price=1500};

            Product.Count++;

            //인스턴스 변수를 생성함과 동시에 값을 지정
            Dog dj = new Dog("nini" ,17);
            MessageBox.Show(dj.name+dj.age);
            Dog abcx = new Dog("Coco", 0);
            MessageBox.Show("개의 수: " + Dog.theNumberofDog);
            
            








        }


    }
}
