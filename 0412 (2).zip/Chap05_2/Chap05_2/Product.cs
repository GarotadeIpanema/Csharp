﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chap05_2
{
    class Product
    {   //static 있으면, 클래스변수, 없으면 인스턴스 변수
        //count는 인스턴스 변수 모든 프로덕트에서 접근 가능한 공통된 변수
        private string name;
        private int price;
        private static int count;

        public string Name { get => name; set => name = value; }
        public int Price { get => price; set => price = value; }
        public static int Count { get => count; set => count = value; }





    }




}
