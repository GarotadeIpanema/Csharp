﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chap05_2
{
    class Dog
    {
        public string name = "이동준";
        public int age = 33;
        public static int theNumberofDog = 0;

        //생성자: 클래스 변수(공통변수)가 가지고 있는 속성을 같이 생성해주는 것
        public Dog(string name, int age)
        {
            this.name = name;
            this.age = age;
            theNumberofDog++;

        }
        






    }
}
