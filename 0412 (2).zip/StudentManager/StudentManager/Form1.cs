﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentManager
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //총 7칸
            List<Student> students = new List<Student>();
            students.Add(new Student() { name="이동준", grade=1});
            Student s = new Student() { name = "준동이", grade = 2 };
            students.Add(s);
            Student ss = new Student();
            ss.name = "동준이";
            ss.grade = 3;
            students.Add(new Student() { name = "김동준", grade = 1 });
            students.Add(new Student() { name = "최동준", grade = 2 });
            students.Add(new Student() { name = "박동준", grade = 3 });
            students.Add(new Student() { name = "양동준", grade = 4 });

            //string names = " ";
            //for (int i = 0; i < students.Count; i++)
            //{
            //    names += students[i].name + " " + students[i].grade + "\n";

            //}
            //MessageBox.Show(names);
            for (int i = 0; i < students.Count; i++)
            {   //디자인창에 코드로 그림
                Label label = new Label();
                label.Text = $"{students[i].grade}학년 {students[i].name}학생";
                label.AutoSize = true;
                label.Location = new Point(13, 13 + (26 * i));
                Controls.Add(label);
                
                
            }
            //for (int i = 0; i < length; i++):일반for문
            //지워나가는 for문은 역for문으로 돌려줘야지 인덱스 범위에서 벗어나는 오류를 피할 수 있음.
            //인덱스값은 0부터 시작하니까 하나 작은 값부터 넣어서 감산해주면 됨
            //1학년만 남기고 다 지우려고 한다
            for (int i = students.Count-1; i >= 0; i--)
            {
                if (students[i].grade > 1)
                    students.RemoveAt(i);
            }
            for (int i = 0; i < students.Count; i++)
            {   //디자인창에 코드로 그림
                Label label = new Label();
                label.Text = $"{students[i].grade}학년 {students[i].name}학생";
                label.AutoSize = true;
                label.Location = new Point(130, 13 + (26 * i));
                Controls.Add(label);


            }

            






        }
    }
}
