﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Day7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string id = txtId.Text;
            string name = txtName.Text;
            string grade = "";
            if(cboGrade.SelectedIndex >= 0)
            {
                grade = cboGrade.Items[cboGrade.SelectedIndex].ToString();
            }
            string date = dtDate.ValueMember.ToShortDateString();
            string amount = "";
            if(cboAmount.SelectedIndex >= 0)
            {
                amount = cboAmount.Items[cboAmount.SelectedIndex].ToString();
            }
            // 각 필드를 콤마로 결합한다.
            string data = id + "," + name + "," + grade + "," + date + "," + amount;
            StreamWriter wr = new StreamWriter("data.txt", true);
            wr.WrteLine(data);
            wr.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            txtId.Text = string.Empty;
            txtName.Text = string.Empty;
            cboGrade.SelectedIndex = -1;
            dtDate.ValueMember = DateTime.Today;
            cboAmount.SelectedIndex = -1;
        }
    }
}
