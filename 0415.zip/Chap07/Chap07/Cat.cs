﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chap07
{
    class Cat
    {

        public string name { get; set; }
        public string age { get; set; }
        public string breedName { get; set; }
        public string salveName { get; set; }

        public void Eat()
        {
            System.Windows.Forms.MessageBox.Show("챱챱");
        }
        public void Meow()
        {
            System.Windows.Forms.MessageBox.Show("냥냥냥냥");
        }

    }
}
