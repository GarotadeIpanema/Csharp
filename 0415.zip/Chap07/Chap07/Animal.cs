﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chap07
{       //공통 인스턴스 변수
    class Animal
    {
        public string name { get; set; }
        public string age { get; set; }
        public string breedName { get; set; }

        public virtual void Fight()
        {
            System.Windows.Forms.MessageBox.Show("퍽퍽!");
        }

        public void Eat()
        {
            System.Windows.Forms.MessageBox.Show("챱챱");
        }
        //Animal의 부모클래스 obj로부터 상속받음
        public override string ToString()
        {
            return "내 주인의 이름은 " + name + "이고, 내 나이는 " + age + "살이야!";

        }

        


    }
}
