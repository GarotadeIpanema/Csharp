﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chap07
{    //New Dog가 Animal이 가지고 있는 속성을 상속받음 =자바의 extends=씨샵의 :
    //new Dog만의 속성은 new dog만 가지고 있음
    class NewDog : Animal
    {
        public virtual void Fight()
        {
            System.Windows.Forms.MessageBox.Show("콱물기!!@");
        }

        public void Bark()
        {
            System.Windows.Forms.MessageBox.Show("왕왕");
        }



    }
}
