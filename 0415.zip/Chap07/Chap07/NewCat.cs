﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chap07
{
    class NewCat : Animal
    {
        public virtual void Fight()
        {
            System.Windows.Forms.MessageBox.Show("할퀴기!!@");
        }
        public void Meow()
        {
            System.Windows.Forms.MessageBox.Show("냥냥냥냥");
        }
    }
}
