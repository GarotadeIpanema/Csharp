﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Recursive_Function
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int.TryParse(textBox1.Text, out int num);
            MessageBox.Show("1부터가 "+num+"까지의 합은" +sum(num) +"이다");
        }
        //재귀함수써서 합구하기: 매개변수가 0이하면 끝남
        //유의할점: return값 없으면 무한루프 걸림
        private int sum(int end)
        {   
            if (end <= 0) return 0;
            return end+ sum(end - 1);
           
        }
        private long recur(int n )
        {
            if (n < 0) return 0;
            if (n == 1) return 1;
            //이부분 틀림
            //if (n == 2) return 1;
            return recur(n-2) + recur(n - 1);
        }

       

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            int.TryParse(textBox2.Text, out int n);
            MessageBox.Show("피보나치수열" + n + "번쨰 값은" + recur(n) + "입니다");
        }
        //4.상속과 다형성-객체지향 특징
        //1.
    }
}
