﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chap06
{
    public partial class Form1 : Form
    {
        Account a1;
        Account a2;

        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

       
        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }
        //계좌를 개설해주는 버튼

        private void button7_Click(object sender, EventArgs e)
        {
            int.TryParse(textBox1.Text, out int money);
            string name = textBox2.Text;
            a1 = new Account(money, name);
            string message = a1.name + "님," + "잔액은 " + a1.myMoney + "입니다.";
            //이름변경 가능하게
            //윈폼 요소들을 모아놓은 집합: controls, 
            //var:타입이 정해져 있지 않은 변수
            foreach (var item in Controls)
            {
                //if( (item as Label) != null)
                //{
                //    if ((item as Label).Name == "temp")
                //        Controls.Remove((item as Label));
                //}
                //item is label: 라벨타입이면
                //item as label: 형변환
                //
                if(item is Label)
                {
                    if ((item as Label).Name == "temp")
                        Controls.Remove(item as Label);

                }

            }

            Label msg = new Label();
            msg.Name = "temp";
            msg.Text = message;
            msg.AutoSize = true;
            msg.Location = new Point(200, 200);
            Controls.Add(msg);
        }

        private void button8_Click(object sender, EventArgs e)
        {      //주소지;포인터
           // a2 = a1; 참조변수의특성상 문제 발생
          
            a2.name = textBox3.Text;
            a2.myMoney = int.Parse(textBox4.Text);


            string message = a2.name + "님," + "잔액은 " + a2.myMoney + "입니다.";
            foreach (var item in Controls)
            {
                if ((item as Label) != null)
                {
                    if ((item as Label).Name == "temp1" || (item as Label).Name == "temp2")
                    { Controls.Remove((item as Label)); }
                }
            }
            Label msg = new Label();
            msg.Name = "temp1";

            msg.Text = message;
            msg.AutoSize = true;
            msg.Location = new Point(200, 250);
            Controls.Add(msg);
          

            Label msg2 = new Label();
            msg.Name = "temp2";
            msg2.Text = a1.name + a1.myMoney;
            msg2.AutoSize = true;
            msg2.Location = new Point(200, 300);
            Controls.Add(msg2);
           
        }


    }
}
