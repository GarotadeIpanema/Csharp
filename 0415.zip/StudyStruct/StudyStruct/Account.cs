﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudyStruct
{   
    //구조체: 스트럭트(클래스는 주소를 저장하는 것처럼 int나 스트링처럼 값을 저장함)
    //a2=a1, 주소가 바뀌는 것이 아니라 값이 바뀜

    struct Account
    {
        //은행 계좌 관리 시스템
        public int myMoney;
        public string name;
        public Account(int money, string name)
        {
            myMoney = money;
            this.name = name;

        }
        //입금, 출금
        public void deposit(int money)
        {
            myMoney += money;
        }
        public void withdraw(int money)
        {
            myMoney -= money;
        }





    }
}
