﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudyStruct
{
    public partial class Form1 : Form
    {   Account a1;
        Account a2;
        //a2=a1; 얕은복사(참조복사), 구조체 복사=깊은복사(값복사)
        //배열과 리스트도 참조변수= 주소지를 갖는다// 구조체는 값을 저장한다=값이 바뀐다.

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Account a1 = new Account(100, textBox1.Text);
            MessageBox.Show(a1.name+a1.myMoney);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            a2 = a1;
            a2.name = textBox2.Text;
            a2.myMoney = 1312;
            MessageBox.Show(a1.name + a1.myMoney);
            MessageBox.Show(a2.name + a2.myMoney);

        }
        //참조변수 개념 매우 중요
        private void swapFunction(int a, int b)
        {   //int a,b가 여기서만 유효한 함수
            int temp = a;
            a = b;
            b = temp;
        }
        //
        private void swapFunction(ref int a, ref int b)
        {   //ref int a: 변수 a의 주소지를 받아오는 것 
            int temp = a;
            a = b;
            b = temp;

        }
        //out키워드를 사용해서 함수 만들기= return이랑 비슷
        //변수 x에 대해 vx+x 값을 반환한다,ref는 주소지값변경
        //이 함수는 반환형은 없지만 2개변수의 값을 바꾼다
        private void NextPosition(int x, int y, int vx, int vy, out int rx, out int ry)
        {
            rx = vx + x;
            ry = vy + y;

        }

        private void button3_Click(object sender, EventArgs e)
        {
            int.TryParse(textBox3.Text, out int a);
            int.TryParse(textBox4.Text, out int b);
            //얕은복사 함수에서의 a,b와 받아온 a,b는 다른것
            swapFunction(a, b);
            //바꿔봤자 함수가 끝나면 소멸됨
            textBox5.Text = a.ToString();
            textBox6.Text = b.ToString();
            MessageBox.Show("변경이 안 되었지?");
            // ref: 주소지가 가리키는 값을 서로 바꾼것
            swapFunction(ref a, ref b);
            MessageBox.Show("변경 완료?");
            textBox5.Text = a.ToString();
            textBox6.Text = b.ToString();
            MessageBox.Show("변경 완료!");
            //int tempA = a;
            //int tempB = b;
            //swapFunction(tempB, tempA, out a, out b);
            //textBox5.Text = a.ToString();
            //textBox6.Text = b.ToString();
            //MessageBox.Show("변경 완료!");



        }


        private void button4_Click(object sender, EventArgs e)
        {
            int.TryParse(textBox8.Text, out int x);
            int.TryParse(textBox7.Text, out int y);
            int.TryParse(textBox10.Text, out int vx);
            int.TryParse(textBox9.Text, out int vy);
            MessageBox.Show($"x={x}, y={y}");
            
            NextPosition(x, y, vx, vy, out x, out y);
            MessageBox.Show($"x={x}, y={y}");

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        //out버튼
        private void button5_Click(object sender, EventArgs e)
        {   //선언함과 동시에 반환형이 없는 함수를 통째로 할당

            //outExample(out int abd, out int def, out int hij);
            //0값이 기본으로 들어감
            int abd;
            int def;
            int hij;
            //out: 한방에 여러변수값을 할당
            outExample(out abd, out def, out hij);

            MessageBox.Show(abd+def+hij+"");
            
            foreach (var item in Controls)
            {
                //if(item is TextBox)//아이템이 텍박인 경우
                //{
                //    (item as TextBox).Text="안녕;
                //}
                //텍박이 아닌 아이템을 텍박으로 형변환함
                var temp = item as TextBox;
                if (temp != null)
                    temp.Text = "민하-";
                
            }


        }
        private void outExample(out int a, out int b, out int c)
        {
            a = 100;
            b = 200;
            c = 300;

        }

    }
}
