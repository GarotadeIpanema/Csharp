﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ManageCar_Program
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            DataManager.Load();
            // List<ParkingCar> cars = new List<ParkingCar>();
            // cars.Add(new ParkingCar() { parkingSpot = 1, carNumber = "30고9484", driverName = "이동준", phoneNumber = "010-2342-2432", parkingTime = DateTime.Now });

            // //두줄이 나옴: cars(참조변수)의 주소지에 두개변수 저장되어있음
            // dataGridView1.DataSource = cars;
            ////총 2개
            // cars.Add(new ParkingCar());
            dataGridView1.DataSource = DataManager.Cars;
            textBox1.Text = DataManager.Cars[0].parkingSpot.ToString();
            textBox2.Text = DataManager.Cars[0].carNumber.ToString();
            textBox3.Text = DataManager.Cars[0].driverName.ToString();
            textBox4.Text = DataManager.Cars[0].phoneNumber.ToString();

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            WhatTime.Text = "지금은: " + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + "입니다.";

        }

        private void toolStripStatusLabel1_Click(object sender, EventArgs e)
        {

        }
        //주차,출차,조회
        private void button1_Click(object sender, EventArgs e)
        {
            writeLog("주차 버튼 클릭");
            //공백을 다 제거했을 때 공백이면
            if(textBox1.Text.Trim() == "")
            {
                MessageBox.Show("주차공간을 입력해라");
            }
            
            else if(textBox2.Text.Trim() == "")// 차량 번호를 입력하지 않은 경우
            {
                
                MessageBox.Show("차번호를 입력해라");
                //로그 남기기
                writeLog("차번호를 입력해라");

            }
            else
            {   //본격 입력작업
                //참조변수,람다(간추린함수:=>형식)개념을 알고 있는 경우
                //파킹카 임시변수 선언(싱글메소드안에 함수(x: cars안에있는 각각의 요소)와 텍박1이 일치할때)
                try
                {
                    ParkingCar car = DataManager.Cars.Single((x) => x.parkingSpot.ToString() == textBox1.Text);
                    if (car.carNumber.Trim() != "")
                    {
                        MessageBox.Show("해당 공간에는 이미 차량이 있습니다.");
                        writeLog("해당 공간에는 이미 차가 있어요." + textBox1.Text);
                    }
                    else//차번호에 차량이 안들어와 있으면 그공간에 차를 넣는다
                        // 참조변수:데이터가 아니라 해당 데이터 주소지를 저장
                    {
                        car.parkingSpot = int.Parse(textBox1.Text);
                        car.carNumber = textBox2.Text;
                        car.driverName = textBox3.Text;
                        car.phoneNumber = textBox4.Text;
                        car.parkingTime = DateTime.Now;

                        dataGridView1.DataSource = null;
                        dataGridView1.DataSource = DataManager.Cars;
                        DataManager.Save();

                        string contens = $"주차공간{textBox1.Text} 에 {textBox2.Text}차를 주차함";
                        MessageBox.Show(contens);
                        writeLog(contens, DateTime.Now.ToString("yyyy_MM_dd"));

                    }
                }
                catch (Exception ex)
                {

                    string contents = "주차 할 수 없습니다" + textBox1.Text;
                    MessageBox.Show(contents);
                    writeLog(contents);
                        
                }
               
            }
        }
        private void writeLog(string contents)
        {   

            string logContens =$"[{DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")}]"+
                $"{contents}";
            //옛날것이 가장 위에 올라가는 방식
            //새로운 내용이 뒤에 추가되어서, 새로운 내용을 보려면 밑으로 내려가야함
            listBox1.Items.Add(logContens);
            //새로운 내용이 가장 앞에 있게 되는 것
            listBox1.Items.Insert(0, logContens);
            DataManager.printLog(logContens);
        }

        //writeLog 오버로딩
        private void writeLog(string contents, string date)
        {

            string logContens = $"[{DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")}]" +
                $"{contents}";
            //옛날것이 가장 위에 올라가는 방식
            //새로운 내용이 뒤에 추가되어서, 새로운 내용을 보려면 밑으로 내려가야함
            listBox1.Items.Add(logContens);
            //새로운 내용이 가장 앞에 있게 되는 것
            listBox1.Items.Insert(0, logContens);
            DataManager.printLog(logContens,date);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            writeLog("출차 버튼 클릭");
            if (textBox1.Text.Trim()=="")
            {
                MessageBox.Show("주차공간 번호를 입력해주세요!");
                //함수 종료
                return;
            }
            //single 없이 조회, 해당 데이터 변경
            try
            {
                for (int i = 0; i < DataManager.Cars.Count; i++)
                {   

                    if (DataManager.Cars[i].parkingSpot.ToString() == textBox1.Text)
                    {
                        if (DataManager.Cars[i].carNumber.Trim()=="")
                        {
                            MessageBox.Show("아직 차 없음");
                            writeLog("아직 차 없음");
                            break;
                        }
                        else
                        {
                            DataManager.Cars[i].carNumber = "";
                            DataManager.Cars[i].driverName = "";
                            DataManager.Cars[i].phoneNumber = "";
                            DataManager.Cars[i].parkingTime = DateTime.Now;
                            string contents = $"주차공간{textBox1.Text}에 {textBox2.Text}차량 출차";
                            MessageBox.Show(contents);
                            writeLog(contents);
                            dataGridView1.DataSource = null;
                            dataGridView1.DataSource = DataManager.Cars;
                            DataManager.Save();
                            break;

                        }
                    }

                }
            }
            catch (Exception ex)
            {
                writeLog("출차 안됨");
                writeLog(ex.Message);
                writeLog(ex.StackTrace);


            }



        }

        private void button3_Click(object sender, EventArgs e)
        {
            writeLog("조회 버튼 클릭");

            //writeLog("3번 버튼 클릭", DateTime.Now.ToString("yyyy_MM_dd"));
            if (textBox5.Text.Trim() == "")
            {
                MessageBox.Show("주차공간 번호를 입력해주세요!");
                //함수 종료
                return;
            }
            //single 없이 조회, 해당 데이터 변경
            try
            {
                for (int i = 0; i < DataManager.Cars.Count; i++)
                {

                    if (DataManager.Cars[i].parkingSpot.ToString() == textBox5.Text)
                    {
                        string contents = $"주차공간: {textBox1.Text}에 {textBox2.Text} 차량 있음";
                        
                        MessageBox.Show(contents);
                        writeLog(contents);

                        break;

                    }
                    else {
                        MessageBox.Show($"해당 공간 {textBox1.Text}에 주차가 가능합니다!");
                        writeLog($"해당 공간 {textBox1.Text}에 주차가 가능합니다!");
                        break;
                         }
                    }
                
            }
            catch (Exception ex)
            {
                writeLog("조회 안됨");
                writeLog(ex.Message);
                writeLog(ex.StackTrace);


            }
    }
        
        //데이터 그리드뷰 번개 이벤트에서 cellclick더블 클릭!!
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                //파킹카에 현재 클릭한 행에 있는 데이터를 파킹카 형태로 묶어서 가져와서 텍박에 써줌
                ParkingCar temp = dataGridView1.CurrentRow.DataBoundItem as ParkingCar;
                textBox1.Text = temp.parkingSpot.ToString();
                textBox2.Text = temp.carNumber;
                textBox3.Text = temp.driverName;
                textBox4.Text = temp.phoneNumber;
                textBox5.Text= temp.parkingSpot.ToString();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
                MessageBox.Show(ex.StackTrace);
                writeLog(ex.Message);
                writeLog(ex.StackTrace);

            }
        }
    }
}
