﻿using MaterialSkin.Controls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chap_05
{
    public partial class Form1 : MaterialForm
    {
        public Form1()
        {   
            InitializeComponent();
            
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //프레임워크위에 씨샵이 돌아감미당, 최신버전 다운받아주어야: 버전이 맞아야 돌아가기 때문
           
            }


        private void Form1_Click(object sender, EventArgs e)
        {

        }

        private void cxFlatRoundButton1_Click(object sender, EventArgs e)
        {

        }

        private void cxFlatRoundButton2_Click(object sender, EventArgs e)
        {

        }

        private void cxFlatRoundButton3_Click(object sender, EventArgs e)
        {

        }

       

        private void cxFlatRoundButton5_Click(object sender, EventArgs e)
        {

        }

        private void button_num6_Click(object sender, EventArgs e)
        {

        }

        private void button_num5_Click(object sender, EventArgs e)
        {

        }

        private void button_test_Click(object sender, EventArgs e)
        {
            CxFlatUI.CxFlatRoundButton[] buttonList = new CxFlatUI.CxFlatRoundButton[6];
            buttonList[0] = button_num1;
            buttonList[1] = button_num2;
            buttonList[2] = button_num3;
            buttonList[3] = button_num4;
            buttonList[4] = button_num5;
            buttonList[5] = button_num6;



            //0이상 10미만 숫자 하나 출력 Next(10)
            //1이상 46미만 숫자 하나 출력 Next(1,46)

            Random r = new Random();
            //0이상 10미만의 숫자 하나 출력
            //MessageBox.Show(r.Next(1,46).ToString());
            //MessageBox.Show 괄호 안에는 스트링 타입만 들어감
            //button_num1.Text = r.Next(1, 46).ToString();
            //button_num1.Refresh();
            //button_num2.Text = r.Next(1, 46).ToString();
            //button_num2.Refresh();

            //button_num3.Text = r.Next(1, 46).ToString();
            //button_num3.Refresh();

            //button_num4.Text = r.Next(1, 46).ToString();
            //button_num4.Refresh();

            //button_num5.Text = r.Next(1, 46).ToString();
            //button_num5.Refresh();

            //button_num6.Text = r.Next(1, 46).ToString();
            //button_num6.Refresh();

            //중복처리  
            int[] a = new int[6];
           

            for (int i = 0; i < 6; i++)
            {
                a[i] = r.Next(1, 46);
                for (int j = 0; j < i; j++)
                {
                    if (a[i] == a[j])
                        i--;
                }
            }
            for (int k = 0; k < 6; k++)
            {
                buttonList[k].Text = (a[k].ToString());
                buttonList[k].Refresh();
            }

            /*num1.Text = r.Next(1, 46).ToString();
            num1.Refresh();
            num2.Text = r.Next(1, 46).ToString();
            num2.Refresh();
            num3.Text = r.Next(1, 46).ToString();
            num3.Refresh();
            num4.Text = r.Next(1, 46).ToString();
            num4.Refresh();
            num5.Text = r.Next(1, 46).ToString();
            num5.Refresh();
            num6.Text = r.Next(1, 46).ToString();
            num6.Refresh();*/










        }
    }
}
