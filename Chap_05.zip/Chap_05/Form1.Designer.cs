﻿
namespace Chap_05
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_test = new System.Windows.Forms.Button();
            this.button_num1 = new CxFlatUI.CxFlatRoundButton();
            this.button_num2 = new CxFlatUI.CxFlatRoundButton();
            this.button_num3 = new CxFlatUI.CxFlatRoundButton();
            this.button_num5 = new CxFlatUI.CxFlatRoundButton();
            this.button_num4 = new CxFlatUI.CxFlatRoundButton();
            this.button_num6 = new CxFlatUI.CxFlatRoundButton();
            this.SuspendLayout();
            // 
            // button_test
            // 
            this.button_test.BackColor = System.Drawing.Color.Transparent;
            this.button_test.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_test.Location = new System.Drawing.Point(41, 117);
            this.button_test.Name = "button_test";
            this.button_test.Size = new System.Drawing.Size(75, 23);
            this.button_test.TabIndex = 0;
            this.button_test.Text = "번호 생성!";
            this.button_test.UseVisualStyleBackColor = false;
            this.button_test.Click += new System.EventHandler(this.button_test_Click);
            // 
            // button_num1
            // 
            this.button_num1.ButtonType = CxFlatUI.ButtonType.Primary;
            this.button_num1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_num1.Location = new System.Drawing.Point(133, 102);
            this.button_num1.Name = "button_num1";
            this.button_num1.Size = new System.Drawing.Size(70, 70);
            this.button_num1.TabIndex = 16;
            this.button_num1.Text = "-";
            this.button_num1.TextColor = System.Drawing.Color.White;
            this.button_num1.Click += new System.EventHandler(this.cxFlatRoundButton1_Click);
            // 
            // button_num2
            // 
            this.button_num2.ButtonType = CxFlatUI.ButtonType.Primary;
            this.button_num2.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_num2.Location = new System.Drawing.Point(237, 102);
            this.button_num2.Name = "button_num2";
            this.button_num2.Size = new System.Drawing.Size(70, 70);
            this.button_num2.TabIndex = 17;
            this.button_num2.Text = "-";
            this.button_num2.TextColor = System.Drawing.Color.White;
            this.button_num2.Click += new System.EventHandler(this.cxFlatRoundButton2_Click);
            // 
            // button_num3
            // 
            this.button_num3.ButtonType = CxFlatUI.ButtonType.Primary;
            this.button_num3.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_num3.Location = new System.Drawing.Point(341, 103);
            this.button_num3.Name = "button_num3";
            this.button_num3.Size = new System.Drawing.Size(70, 70);
            this.button_num3.TabIndex = 18;
            this.button_num3.Text = "-";
            this.button_num3.TextColor = System.Drawing.Color.White;
            this.button_num3.Click += new System.EventHandler(this.cxFlatRoundButton3_Click);
            // 
            // button_num5
            // 
            this.button_num5.ButtonType = CxFlatUI.ButtonType.Primary;
            this.button_num5.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_num5.Location = new System.Drawing.Point(533, 103);
            this.button_num5.Name = "button_num5";
            this.button_num5.Size = new System.Drawing.Size(70, 70);
            this.button_num5.TabIndex = 19;
            this.button_num5.Text = "-";
            this.button_num5.TextColor = System.Drawing.Color.White;
            this.button_num5.Click += new System.EventHandler(this.button_num5_Click);
            // 
            // button_num4
            // 
            this.button_num4.ButtonType = CxFlatUI.ButtonType.Primary;
            this.button_num4.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_num4.Location = new System.Drawing.Point(436, 103);
            this.button_num4.Name = "button_num4";
            this.button_num4.Size = new System.Drawing.Size(70, 70);
            this.button_num4.TabIndex = 20;
            this.button_num4.Text = "-";
            this.button_num4.TextColor = System.Drawing.Color.White;
            this.button_num4.Click += new System.EventHandler(this.cxFlatRoundButton5_Click);
            // 
            // button_num6
            // 
            this.button_num6.ButtonType = CxFlatUI.ButtonType.Primary;
            this.button_num6.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_num6.Location = new System.Drawing.Point(631, 103);
            this.button_num6.Name = "button_num6";
            this.button_num6.Size = new System.Drawing.Size(70, 70);
            this.button_num6.TabIndex = 21;
            this.button_num6.Text = "-";
            this.button_num6.TextColor = System.Drawing.Color.White;
            this.button_num6.Click += new System.EventHandler(this.button_num6_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(743, 251);
            this.Controls.Add(this.button_num6);
            this.Controls.Add(this.button_num4);
            this.Controls.Add(this.button_num5);
            this.Controls.Add(this.button_num3);
            this.Controls.Add(this.button_num2);
            this.Controls.Add(this.button_num1);
            this.Controls.Add(this.button_test);
            this.Name = "Form1";
            this.Text = "로또번호생성기";
            this.Click += new System.EventHandler(this.Form1_Click);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_test;
        private CxFlatUI.CxFlatRoundButton button_num1;
        private CxFlatUI.CxFlatRoundButton button_num2;
        private CxFlatUI.CxFlatRoundButton button_num3;
        private CxFlatUI.CxFlatRoundButton button_num5;
        private CxFlatUI.CxFlatRoundButton button_num4;
        private CxFlatUI.CxFlatRoundButton button_num6;
    }
}

