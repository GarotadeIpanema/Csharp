﻿using System;

namespace Ex4_15
{
    class Program
    {
        static void Main(string[] args)
        {
            long start = DateTime.Now.Ticks;
            long count = 0;
            while (start + (1000000) > DateTime.Now.Ticks)
            {
                count++;
            }
            Console.WriteLine(count + " 만큼 반복했습니다");
        }
    }
}
