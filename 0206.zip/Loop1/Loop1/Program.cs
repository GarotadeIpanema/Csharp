﻿using System;

namespace Loop1
{
    class Program
    {
        static void Main(string[] args) { 
        for(int i=0;i<1000;i++){

            Console.WriteLine("출력");
        }
    }
    }
}
