﻿using System;

namespace Ex4_7
{
    class Program
    {
        static void Main(string[] args)
        {
           for(int i = '가';i <= '힣'; i++)
            {
                Console.WriteLine((char)i);
            }
        }
    }
}
