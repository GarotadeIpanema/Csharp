﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Last
{
    public partial class Form1 : Form
    {
        public List<string> list = new List<string>();
        public Form1()
        {
            InitializeComponent();
            //list.Add(button1.Text);


            //for (int i = 0; i < 6; i++)
            //{
            //    Button b = new Button();
            //    b.Text = list[i];
            //    b.Location = new Point(5+100*i, 50);
            //    Controls.Add(b);
            //}
            label2.AutoSize = true;


        }

        private void button1_Click(object sender, EventArgs e)
        {

            list.Add(button1.Text);
            label2.Text = "";
            foreach(var item in list)
            {
                label2.Text += item + " ";
            }
                
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            list.Add(button2.Text);
            label2.Text = "";
            foreach (var item in list)
            {
                label2.Text += item + " ";
            }
        }
     

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {

            list.Remove(button8.Text);
            label2.Text = "";
            foreach (var item in list)
            {
                label2.Text += item + " ";
            }


        }

        private void button7_Click(object sender, EventArgs e)
        {

            list.Remove(button7.Text);
            label2.Text = "";
            
            foreach (var item in list)
            {
                label2.Text += item + " ";
                
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {

            list.Remove(button6.Text);
            label2.Text = "";
            foreach (var item in list)
            {
                label2.Text += item + " ";
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            

            list.Remove(button5.Text);
            label2.Text = "";
            foreach (var item in list)
            {
                label2.Text += item + " ";
            }
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            list.Add(button3.Text);
            label2.Text = "";
            foreach (var item in list)
            {
                label2.Text += item + " ";
            }
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            list.Add(button4.Text);
            label2.Text = "";
            foreach (var item in list)
            {
                label2.Text += item + " ";
            }
        }
    }
}
