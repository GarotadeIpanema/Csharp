﻿
namespace Chap_05
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_test = new System.Windows.Forms.Button();
            this.button_num1 = new Sunny.UI.UISymbolButton();
            this.button_num2 = new Sunny.UI.UISymbolButton();
            this.button_num3 = new Sunny.UI.UISymbolButton();
            this.button_num4 = new Sunny.UI.UISymbolButton();
            this.button_num5 = new Sunny.UI.UISymbolButton();
            this.button_num6 = new Sunny.UI.UISymbolButton();
            this.button_num7 = new Sunny.UI.UISymbolButton();
            this.SuspendLayout();
            // 
            // button_test
            // 
            this.button_test.BackColor = System.Drawing.Color.Transparent;
            this.button_test.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_test.Location = new System.Drawing.Point(37, 127);
            this.button_test.Name = "button_test";
            this.button_test.Size = new System.Drawing.Size(75, 23);
            this.button_test.TabIndex = 0;
            this.button_test.Text = "번호 생성!";
            this.button_test.UseVisualStyleBackColor = false;
            this.button_test.Click += new System.EventHandler(this.button_test_Click);
            // 
            // button_num1
            // 
            this.button_num1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_num1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(133)))), ((int)(((byte)(244)))));
            this.button_num1.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.button_num1.IsCircle = true;
            this.button_num1.Location = new System.Drawing.Point(148, 102);
            this.button_num1.MinimumSize = new System.Drawing.Size(1, 1);
            this.button_num1.Name = "button_num1";
            this.button_num1.Size = new System.Drawing.Size(70, 70);
            this.button_num1.Style = Sunny.UI.UIStyle.Custom;
            this.button_num1.SymbolSize = 0;
            this.button_num1.TabIndex = 23;
            this.button_num1.Text = "-";
            this.button_num1.Click += new System.EventHandler(this.uiSymbolButton1_Click);
            // 
            // button_num2
            // 
            this.button_num2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_num2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(67)))), ((int)(((byte)(53)))));
            this.button_num2.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.button_num2.IsCircle = true;
            this.button_num2.Location = new System.Drawing.Point(245, 103);
            this.button_num2.MinimumSize = new System.Drawing.Size(1, 1);
            this.button_num2.Name = "button_num2";
            this.button_num2.Size = new System.Drawing.Size(70, 70);
            this.button_num2.Style = Sunny.UI.UIStyle.Custom;
            this.button_num2.SymbolSize = 0;
            this.button_num2.TabIndex = 24;
            this.button_num2.Text = "-";
            // 
            // button_num3
            // 
            this.button_num3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_num3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(188)))), ((int)(((byte)(5)))));
            this.button_num3.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.button_num3.IsCircle = true;
            this.button_num3.Location = new System.Drawing.Point(337, 103);
            this.button_num3.MinimumSize = new System.Drawing.Size(1, 1);
            this.button_num3.Name = "button_num3";
            this.button_num3.Size = new System.Drawing.Size(70, 70);
            this.button_num3.Style = Sunny.UI.UIStyle.Custom;
            this.button_num3.SymbolSize = 0;
            this.button_num3.TabIndex = 25;
            this.button_num3.Text = "-";
            this.button_num3.Click += new System.EventHandler(this.uiSymbolButton3_Click);
            // 
            // button_num4
            // 
            this.button_num4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_num4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(133)))), ((int)(((byte)(244)))));
            this.button_num4.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.button_num4.IsCircle = true;
            this.button_num4.Location = new System.Drawing.Point(430, 103);
            this.button_num4.MinimumSize = new System.Drawing.Size(1, 1);
            this.button_num4.Name = "button_num4";
            this.button_num4.Size = new System.Drawing.Size(70, 70);
            this.button_num4.Style = Sunny.UI.UIStyle.Custom;
            this.button_num4.SymbolSize = 0;
            this.button_num4.TabIndex = 26;
            this.button_num4.Text = "-";
            // 
            // button_num5
            // 
            this.button_num5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_num5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(168)))), ((int)(((byte)(83)))));
            this.button_num5.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.button_num5.IsCircle = true;
            this.button_num5.Location = new System.Drawing.Point(521, 103);
            this.button_num5.MinimumSize = new System.Drawing.Size(1, 1);
            this.button_num5.Name = "button_num5";
            this.button_num5.Size = new System.Drawing.Size(70, 70);
            this.button_num5.Style = Sunny.UI.UIStyle.Custom;
            this.button_num5.SymbolSize = 0;
            this.button_num5.TabIndex = 27;
            this.button_num5.Text = "-";
            // 
            // button_num6
            // 
            this.button_num6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_num6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(67)))), ((int)(((byte)(53)))));
            this.button_num6.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.button_num6.IsCircle = true;
            this.button_num6.Location = new System.Drawing.Point(617, 103);
            this.button_num6.MinimumSize = new System.Drawing.Size(1, 1);
            this.button_num6.Name = "button_num6";
            this.button_num6.Size = new System.Drawing.Size(70, 70);
            this.button_num6.Style = Sunny.UI.UIStyle.Custom;
            this.button_num6.SymbolSize = 0;
            this.button_num6.TabIndex = 28;
            this.button_num6.Text = "-";
            // 
            // button_num7
            // 
            this.button_num7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_num7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(87)))), ((int)(((byte)(172)))));
            this.button_num7.Font = new System.Drawing.Font("Microsoft YaHei", 12F);
            this.button_num7.IsCircle = true;
            this.button_num7.Location = new System.Drawing.Point(720, 103);
            this.button_num7.MinimumSize = new System.Drawing.Size(1, 1);
            this.button_num7.Name = "button_num7";
            this.button_num7.Size = new System.Drawing.Size(70, 70);
            this.button_num7.Style = Sunny.UI.UIStyle.Custom;
            this.button_num7.SymbolSize = 0;
            this.button_num7.TabIndex = 29;
            this.button_num7.Text = "-";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(802, 251);
            this.Controls.Add(this.button_num7);
            this.Controls.Add(this.button_num6);
            this.Controls.Add(this.button_num5);
            this.Controls.Add(this.button_num4);
            this.Controls.Add(this.button_num3);
            this.Controls.Add(this.button_num2);
            this.Controls.Add(this.button_num1);
            this.Controls.Add(this.button_test);
            this.Name = "Form1";
            this.Text = "로또번호생성기";
            this.Click += new System.EventHandler(this.Form1_Click);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_test;
        private Sunny.UI.UISymbolButton button_num1;
        private Sunny.UI.UISymbolButton button_num2;
        private Sunny.UI.UISymbolButton button_num3;
        private Sunny.UI.UISymbolButton button_num4;
        private Sunny.UI.UISymbolButton button_num5;
        private Sunny.UI.UISymbolButton button_num6;
        private Sunny.UI.UISymbolButton button_num7;
    }
}

