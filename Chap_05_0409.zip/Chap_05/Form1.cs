﻿using MaterialSkin.Controls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chap_05
{
    public partial class Form1 : MaterialForm
    {
        public Form1()
        {   
            InitializeComponent();
            
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //프레임워크위에 씨샵이 돌아감미당, 최신버전 다운받아주어야: 버전이 맞아야 돌아가기 때문
           
            }


        private void Form1_Click(object sender, EventArgs e)
        {

        }

        private void cxFlatRoundButton1_Click(object sender, EventArgs e)
        {

        }

        private void cxFlatRoundButton2_Click(object sender, EventArgs e)
        {

        }

        private void cxFlatRoundButton3_Click(object sender, EventArgs e)
        {

        }

       

        private void cxFlatRoundButton5_Click(object sender, EventArgs e)
        {

        }

        private void button_num6_Click(object sender, EventArgs e)
        {

        }

        private void button_num5_Click(object sender, EventArgs e)
        {

        }



        private void button_test_Click(object sender, EventArgs e)
        {
            Sunny.UI.UISymbolButton[] buttonList = new Sunny.UI.UISymbolButton[7];
            buttonList[0] = button_num1;
            buttonList[1] = button_num2;
            buttonList[2] = button_num3;
            buttonList[3] = button_num4;
            buttonList[4] = button_num5;
            buttonList[5] = button_num6;
            buttonList[6] = button_num7;


            //0이상 10미만 숫자 하나 출력 Next(10)
            //1이상 46미만 숫자 하나 출력 Next(1,46)

            Random r = new Random();
            //0이상 10미만의 숫자 하나 출력
            //MessageBox.Show(r.Next(1,46).ToString());
            //MessageBox.Show 괄호 안에는 스트링 타입만 들어감
            //button_num1.Text = r.Next(1, 46).ToString();
            //button_num1.Refresh();
            //button_num2.Text = r.Next(1, 46).ToString();
            //button_num2.Refresh();

            //button_num3.Text = r.Next(1, 46).ToString();
            //button_num3.Refresh();

            //button_num4.Text = r.Next(1, 46).ToString();
            //button_num4.Refresh();

            //button_num5.Text = r.Next(1, 46).ToString();
            //button_num5.Refresh();

            //button_num6.Text = r.Next(1, 46).ToString();
            //button_num6.Refresh();

            //중복처리  
            int[] a = new int[7];


            //#패턴1. 당첨번호 6개를 모두 더해 합계를 구해보니, 121~140사이가 25.2%로 가장 많이 나왔다.
            //합계 100~200사이가 전체의 80%로 10번 추첨하면 8번이나 이 구간에서 당첨번호 조합이 출현하고 있다.
            //지금까지 합계가 48보다 작거나, 238보다 큰 당첨번호는 한번도 없었다.

            //#패턴2. 당첨번호가 연속번호로 나올 경우도 있다. 예를 들어 1, 2, 3, 4, 5, 6 등.
            //이 경우는 3자리 번호가 연속으로 나온 경우는 30회 정도, 4자리 번호는 단 1회뿐이었다.
            //5자리나 6자리의 연속된 번호들은 지금까지 단 한 차례도 없었다.

            //#패턴3. 몇 번째 자리에 어떤 번호가 오는지도 연구대상이다. 첫 번째 자리는 1~34,
            //둘째 자리는 2~36, 셋째 자리는 3~39…. 이런 범위를 벗어나는 번호조합 역시 과거 당첨번호로 출현한 적이 없었다.

            int sum = 0;
           Again:
            for (int i = 0; i < 7; i++)
            {
                a[i] = r.Next(1, 46);
                sum += a[i];

                for (int j = 0; j < i; j++) {

                    if (a[i] == a[j])
                    {
                        sum -= a[i];
                        i--;
                        break;
                    }

                    if (sum > 238)
                    {
                        Console.WriteLine("sum1:" + sum);
                        i = -1;
                        sum = 0;
                        break;
                    }
                    if ((a[0] > 34))
                    {
                        Console.WriteLine("sum2:" + sum + "a[0]" + a[0]);

                        i = -1;
                        sum = 0;
                        break;
                    }
                    if (i == 1 && (a[1] > 36) || (a[1] < 2))
                    {
                        Console.WriteLine("sum3:" + sum + "a[1]" + a[1]);

                        i = -1;
                        sum = 0;
                        break;
                    }
                    if (i == 2 && (a[2] > 39 || a[2] < 3))
                    {
                        Console.WriteLine("sum4:" + sum + "a[2]" + a[2]);

                        i = -1;
                        sum = 0;
                        break;
                    }
                    if (i == 6 && sum < 48)
                    {
                        Console.WriteLine("sum5:" + sum);

                        i = -1;
                        sum = 0;
                        break;
                    }

                }

            }

            //Array.Sort(a);
            //고저 차 41-44일 경우가 확률적으로 높음
            if ((a[5] - a[0] > 44) || (a[5] - a[0] < 41))
            {

                sum = 0;
                goto Again;

            }



            int temp;    //임의로 MAX값 넣을 공간
            int  c, u;      //FOR문 증가값
            for (c = 0; c < 6; c++)

            {

                for (u = 0; u < 5; u++)

                {

                    if (a[u] > a[u + 1]) //연달아있는 두수중 앞에 있는수가 크다면

                    {
                        //위치 변경

                        temp = a[u];
                        a[u] = a[u + 1];

                        a[u + 1] = temp;

                    }//if


                }//for(k)

            }//for(j)




            //MessageBox.Show("당첨될 확률이 높은 번호!!!");
            for (int k = 0; k < 7; k++) 
            {
                buttonList[k].Text = (a[k].ToString());
                buttonList[k].Refresh();
            }

            /*num1.Text = r.Next(1, 46).ToString();
            num1.Refresh();
            num2.Text = r.Next(1, 46).ToString();
            num2.Refresh();
            num3.Text = r.Next(1, 46).ToString();
            num3.Refresh();
            num4.Text = r.Next(1, 46).ToString();
            num4.Refresh();
            num5.Text = r.Next(1, 46).ToString();
            num5.Refresh();
            num6.Text = r.Next(1, 46).ToString();
            num6.Refresh();*/


        }

        private void button_num7_Click(object sender, EventArgs e)
        {

        }

        private void uiSymbolButton1_Click(object sender, EventArgs e)
        {

        }

        private void uiSymbolButton3_Click(object sender, EventArgs e)
        {

        }
    }
}
